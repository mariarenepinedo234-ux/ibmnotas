-- IBM Notas | 6 carreras y 141 materias.
-- Ejecutar el archivo completo en pgAdmin Query Tool sobre la base de IBM Notas.
-- Requiere las tablas del portal (npm run db:migrate). No carga usuarios ni notas.

BEGIN;

CREATE TEMP TABLE ibm_catalog_import_session (marker boolean) ON COMMIT DROP;

CREATE FUNCTION pg_temp.ibm_name_key(value text)
RETURNS text LANGUAGE sql IMMUTABLE STRICT AS $key$
  SELECT upper(trim(regexp_replace(
    regexp_replace(normalize(value, NFD), U&'[\0300-\036f]', '', 'g'),
    '[[:space:]]+', ' ', 'g'
  )));
$key$;

DO $import$
DECLARE
  catalog jsonb := $catalog$
{
  "careers": [
    "ADMINISTRACIÓN DE EMPRESAS",
    "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
    "CONTADURÍA GENERAL",
    "MERCADOTECNIA",
    "SECRETARIADO EJECUTIVO",
    "SISTEMAS INFORMÁTICOS"
  ],
  "subjects": [
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "FUNDAMENTO DE LA ADMINISTRACIÓN",
      "code": "FUA-101",
      "previous_names": [
        "FUNDAMENTO DE LA ADMINISTRACION"
      ]
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "GESTIÓN SECRETARIAL I",
      "code": "GES-101"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "REGÍMENES ADUANEROS",
      "code": "RDA-101",
      "previous_names": [
        "REGIMENES ADUANEROS"
      ]
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "FUNDAMENTOS DE MARKETING",
      "code": "FDM-101"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "LEGISLACIÓN LABORAL Y SEGURIDAD SOCIAL APLICADA",
      "code": "LSA-101"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "INGLÉS TÉCNICO",
      "code": "INT-102"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "GRAMÁTICA NORMATIVA",
      "code": "GRA-102"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "METROLOGÍA Y CLASIFICACIÓN ARANCELARIA",
      "code": "MCA-102",
      "previous_names": [
        "METROLOGÍAY CLASIFICACIÓN ARANCELARIA"
      ]
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "COMPORTAMIENTO DEL CONSUMIDOR",
      "code": "CDC-102"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "INGLÉS TÉCNICO",
      "code": "INT-102"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "CONTABILIDAD GENERAL PARA ADMINISTRACIONES",
      "code": "CGA-103"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "REDACCIÓN Y CORRESPONDENCIA I",
      "code": "REC-103"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "INTEGRACIÓN ECONÓMICA Y NORMAS DE ORIGEN",
      "code": "IEN-103",
      "previous_names": [
        "INTEGRACIÓN ECONÓMICAY NORMAS DE ORIGEN"
      ]
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "SERVICIO Y ATENCIÓN AL CLIENTE",
      "code": "SAC-103"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "CONTABILIDAD I",
      "code": "CON-103"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "MATEMÁTICA FINANCIERA",
      "code": "MAF-104"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "OFIMÁTICA I",
      "code": "OFI-104",
      "previous_names": [
        "OFIMÁTICAI"
      ]
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "GESTIÓN COMERCIAL TRIBUTARIA",
      "code": "GCT-104"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "INFORMÁTICA APLICADA A MARKETING",
      "code": "IAM-104"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "MATEMÁTICA FINANCIERA",
      "code": "MAF-104"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "ESTADÍSTICA PARA LOS NEGOCIOS",
      "code": "ESN-105",
      "previous_names": [
        "ESTADISTICA PARA LOS NEGOCIOS"
      ]
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "DOCUMENTOS MERCANTILES",
      "code": "DOM-105"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "TALLER DE EMPRENDIMIENTO E IDEAS DE NEGOCIOS",
      "code": "TEI-105"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "INGLÉS TÉCNICO DE MERCADOTECNIA",
      "code": "ITM-105"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "INFORMÁTICA CONTABLE",
      "code": "ICO-105"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "PRACTICA LABORAL Y TRIBUTARIA",
      "code": "PLT-106"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "ARCHIVISTA FÍSICA Y DIGITAL",
      "code": "AFD-106",
      "previous_names": [
        "ARCHIVÍSTA FÍSICA Y DIGITAL"
      ]
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "CONTABILIDAD GENERAL",
      "code": "COG-106"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "ANÁLISIS ECONÓMICO Y CONTABILIDAD APLICADA MARKETING",
      "code": "AEC-106"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "ECONOMÍA GENERAL APLICADA",
      "code": "EGA-106"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "INFORMÁTICA EMPRESARIAL",
      "code": "IFE-107"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "IDIOMA ORIGINARIO I",
      "code": "IDO-107"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "MERCADOTECNIA GENERAL",
      "code": "MEG-107"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "ESTADÍSTICA APLICADA A MARKETING",
      "code": "EAM-107"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "DOCUMENTOS COMERCIALES Y MERCANTILES",
      "code": "DCM-107"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 1,
      "name": "EMPRENDIMIENTO PRODUCTIVO",
      "code": "EMP-108"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "MECANOGRAFÍA COMPUTARIZADA",
      "code": "MEC-108"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "DISEÑO GRAFICO PUBLICITARIO",
      "code": "DGP-108"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 1,
      "name": "INTRODUCCIÓN TÉCNICAS DE VENTAS",
      "code": "ITV-108",
      "previous_names": [
        "INTRODUCCIÓNA TÉCNICAS DE VENTAS"
      ]
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "ESTADÍSTICA APLICADA",
      "code": "ESA-108",
      "previous_names": [
        "ESTADISTICA APLICADA"
      ]
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 1,
      "name": "INGLÉS COMERCIAL I",
      "code": "INC-109"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 1,
      "name": "ESTADÍSTICA DESCRIPTIVA",
      "code": "ESD-109"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 1,
      "name": "ADMINISTRACIÓN GENERAL",
      "code": "ADG-109"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "ORGANIZACIÓN DE LA ADMINISTRACIÓN",
      "code": "ORA-201"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "GESTIÓN SECRETARIAL II",
      "code": "GES-201"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "PROCESOS Y SISTEMAS ADUANEROS",
      "code": "PSA-201"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "GESTIÓN DE PRODUCTO Y MARCA",
      "code": "GPM-201"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 2,
      "name": "CONTABILIDAD II",
      "code": "CON-201"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "INVESTIGACIÓN Y ESTRATEGIA DE MERCADO",
      "code": "IDM-202"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "INGLES COMERCIAL II",
      "code": "INC-202"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "CLASIFICACIÓN ARANCELARIA Y MERCEOLOGÍA",
      "code": "CAM-202",
      "previous_names": [
        "CLASIFICACIÓNARANCELARIAY MERCEOLOGÍA"
      ]
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "DETERMINACIÓN DE COSTOS PARA LA FIJACIÓN DE PRECIOS",
      "code": "DCP-202"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 2,
      "name": "CONTABILIDAD DE COSTOS I",
      "code": "COC-202"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "ADMINISTRACIÓN DE OPERACIONES",
      "code": "ADO-203",
      "previous_names": [
        "ADMINISTRACION DE OPERACIONES"
      ]
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "REDACCIÓN Y CORRESPONDENCIA II",
      "code": "REC-203"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "LOGÍSTICA TRANSPORTE INTERNACIONAL",
      "code": "LTI-203",
      "previous_names": [
        "LOGISTICAY TRANSPORTE INTERNACIONAL"
      ]
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "GESTIÓN DE DISTRIBUCIÓN",
      "code": "GDD-203"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 2,
      "name": "CONTABILIDAD DE SOCIEDADES",
      "code": "COS-203"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "GESTIÓN DEL TALENTO HUMANO",
      "code": "GTH-204"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "OFIMÁTICA II",
      "code": "OFI-204"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "NEGOCIACIÓN INTERNACIONAL",
      "code": "NIN-204"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "PUBLICIDAD Y PRODUCCIÓN AUDIOVISUAL",
      "code": "PPA-204"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 2,
      "name": "CONTABILIDAD DE SEGUROS",
      "code": "CDS-204"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "ADMINISTRACIÓN FINANCIERA I",
      "code": "ADF-205"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "CONTABILIDAD I",
      "code": "CON-205"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "INVESTIGACIÓN DE MERCADOS",
      "code": "INM-205"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "MARKETING PÚBLICO DE SERVICIOS Y SOCIAL",
      "code": "MPS-205"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 2,
      "name": "CONTABILIDAD BANCARIA Y COOPERATIVAS",
      "code": "CBC-205"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "PREPARACIÓN Y EVALUACIÓN DE PROYECTOS",
      "code": "PEP-206"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "RELACIONES HUMANAS Y ÉTICA PROFESIONAL",
      "code": "RHE-206"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "CONTABILIDAD DE COSTOS",
      "code": "CDC-206"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "DISEÑO GRÁFICO PUBLICITARIO",
      "code": "DGP-206"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 2,
      "name": "SISTEMA TRIBUTARIO",
      "code": "SIT-206"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "ADMINISTRACIÓN DE COSTOS Y PRESUPUESTOS",
      "code": "ACP-207"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "IDIOMA ORIGINARIO II",
      "code": "IDO-207"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "MERCADOTECNIA INTERNACIONAL Y HERRAMIENTAS DE PROSPECCIÓN",
      "code": "MIH-207"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "INVESTIGACIÓN DE MERCADOS",
      "code": "IDM-207"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 2,
      "name": "INVESTIGACIÓN APLICADA Y EMPRENDIMIENTO",
      "code": "IAE-207"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 2,
      "name": "ECONOMÍA DE LA EMPRESA",
      "code": "EMP-208"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 2,
      "name": "GESTIÓN DOCUMENTAL Y ARCHIVO",
      "code": "GDA-208"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 2,
      "name": "E-COMMERCE Y MERCADOTECNIA EN INTERNET",
      "code": "EMI-208"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 2,
      "name": "MARKETING DIRECTO Y RELACIONES PÚBLICAS",
      "code": "MDR-208"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 3,
      "name": "ADMINISTRACIÓN DE LA MICRO Y PEQUEÑA Y MEDIANA EMPRESA",
      "code": "AMP-301",
      "previous_names": [
        "ADMINISTRACIÓN DE LA MICRO Y PEQUELA Y MEDIANA EMPRESA"
      ]
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 3,
      "name": "ADMINISTRACIÓN ORGANIZACIONAL Y MEDIO AMBIENTE",
      "code": "AOM-301"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 3,
      "name": "TALLER DE MODALIDAD DE GRADUACIÓN",
      "code": "TMG-301"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "DIRECCIÓN Y PROMOCIÓN DE VENTAS",
      "code": "DPV-301"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "CONTABILIDAD AGROPECUARIA",
      "code": "COA-301"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 3,
      "name": "INCUBACIÓN Y MODELO DE NEGOCIOS",
      "code": "INM-302"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 3,
      "name": "INGLÉS EMPRESARIAL",
      "code": "INE-302"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 3,
      "name": "OPERATIVIZACIÓN ADUANERA",
      "code": "OPA-302",
      "previous_names": [
        "OPERATIVIZACIÓNADUANERA"
      ]
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "MARKETING ESTRATÉGICO",
      "code": "MEE-302"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "CONTABILIDAD DE COSTOS II",
      "code": "COC-302"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 3,
      "name": "ESTRATEGIAS DE MERCADOTECNIA",
      "code": "ESM-303",
      "previous_names": [
        "ESTRATÉGIAS DE MERCADOTECNIA"
      ]
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 3,
      "name": "REDACCIÓN Y CORRESPONDENCIA III",
      "code": "REC-303"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 3,
      "name": "DISTRIBUCIÓN FÍSICA INTERNACIONAL",
      "code": "DFI-303"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "MERCADOTECNIA INTERNACIONAL",
      "code": "MEI-303"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "CONTABILIDAD GUBERNAMENTAL",
      "code": "COG-303",
      "previous_names": [
        "CONTABILIDAD GUBERRNAMENTAL"
      ]
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 3,
      "name": "ADMINISTRACIÓN FINANCIERA II",
      "code": "ADF-304"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 3,
      "name": "TALLER DE MODALIDAD DE GRADUACIÓN",
      "code": "TMG-304"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 3,
      "name": "INGLÉS TÉCNICO",
      "code": "INT-304"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "MARKETING RELACIONAL Y CRM",
      "code": "MRC-304"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "CONTABILIDAD EXTRACTIVA(MINERA, PETROLERA Y FORESTAL)",
      "code": "CEP-304"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 3,
      "name": "COMERCIO INTERNACIONAL",
      "code": "CMI-305"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 3,
      "name": "CONTABILIDAD II",
      "code": "CON-305"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 3,
      "name": "ADMINISTRACIÓN EMPRESARIAL",
      "code": "ADE-305"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "MARKETING DIGITAL",
      "code": "MKD-305"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "CONTABILIDAD DE SERVICIOS(CONSTRUCCIÓN, HOTELERÍA Y TRANSPORTE)",
      "code": "CHS-305",
      "previous_names": [
        "CONTABILIDAD DE SERVICIOS(CONSTRUCCIÓN, HOTELERPIA Y TRANSPORTE)"
      ]
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 3,
      "name": "GESTIÓN ESTRATÉGICA",
      "code": "GEE-306"
    },
    {
      "career": "SECRETARIADO EJECUTIVO",
      "level": 3,
      "name": "RELACIONES PÚBLICAS Y ORGANIZACIÓN DE EVENTOS",
      "code": "RPO-306"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 3,
      "name": "PRESUPUESTO Y EVALUACIÓN FINANCIERA",
      "code": "PEF-306"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "EMPRENDIMIENTO PRODUCTIVO",
      "code": "EMP-306"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "GABINETE CONTABLE INFORMÁTICO",
      "code": "GCI-306"
    },
    {
      "career": "ADMINISTRACIÓN DE EMPRESAS",
      "level": 3,
      "name": "TALLER DE MODALIDAD DE GRADUACIÓN",
      "code": "TMG-307"
    },
    {
      "career": "COMERCIO INTERNACIONAL Y ADMINISTRACIÓN ADUANERA",
      "level": 3,
      "name": "TRAMITOLOGÍA DE DOCUMENTOS SOPORTE",
      "code": "TDS-307"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "TALLER DE MODALIDAD DE GRADUACIÓN",
      "code": "TMG-307"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "ANÁLISIS E INTERPRETACIÓN DE ESTADOS FINANCIEROS",
      "code": "AEF-307"
    },
    {
      "career": "MERCADOTECNIA",
      "level": 3,
      "name": "ANÁLISIS DE LA COMPETENCIA Y TÉCNICAS DE NEGOCIACIÓN",
      "code": "ACN-308"
    },
    {
      "career": "CONTADURÍA GENERAL",
      "level": 3,
      "name": "TALLER DE MODALIDAD DE GRADUACIÓN",
      "code": "TMG-308",
      "previous_names": [
        "TALLER DE MODALIDAD DE GRADUACION"
      ]
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 1,
      "name": "HARDWARE DE COMPUTADORAS",
      "code": "HSA-101"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 1,
      "name": "INGLÉS TÉCNICO",
      "code": "INT-102"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 1,
      "name": "MATEMÁTICA PARA LA INFORMÁTICA",
      "code": "MPI-103"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 1,
      "name": "PROGRAMACIÓN I",
      "code": "PRG-104"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 1,
      "name": "TALLER DE SISTEMAS OPERATIVOS",
      "code": "TSO-105"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 1,
      "name": "OFIMÁTICA Y TECNOLOGÍA MULTIMEDIA",
      "code": "OTM-106"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 1,
      "name": "DISEÑO Y PROGRAMACIÓN WEB I",
      "code": "DPW-107"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "ESTADÍSTICA",
      "code": "EST-201",
      "previous_names": [
        "ESTADISTICA"
      ]
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "PROGRAMACIÓN II",
      "code": "PRG-202"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "REDES DE COMPUTADORAS I",
      "code": "RDC-203"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "PROGRAMACIÓN MÓVIL I",
      "code": "PDM-204",
      "previous_names": [
        "PROGRAMACIÓN MOVIL I"
      ]
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "ANÁLISIS Y DISEÑO DE SISTEMAS I",
      "code": "ADS-205"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "DISEÑO Y PROGRAMACIÓN WEB II",
      "code": "DPW-206"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "BASE DE DATOS I",
      "code": "BDD-207"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 2,
      "name": "EMPRENDIMIENTO PRODUCTIVO",
      "code": "ELE-208"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "GESTIÓN Y MEJORAMIENTO DE LA CALIDAD DE SOFTWARE",
      "code": "GMC-301"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "REDES DE COMPUTADORAS II",
      "code": "RDC-302"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "DISEÑO Y PROGRAMACIÓN WEB III",
      "code": "DPW-303"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "PROGRAMACIÓN MÓVIL II",
      "code": "PDM-304",
      "previous_names": [
        "PROGRAMACIÓN MOVIL II"
      ]
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "ANÁLISIS Y DISEÑO DE SISTEMAS II",
      "code": "ADS-305"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "BASE DE DATOS II",
      "code": "BDD-306"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "PROYECTOS DE INNOVACIÓN Y COMPUTACIÓN EN LA NUBE",
      "code": "PIC-307"
    },
    {
      "career": "SISTEMAS INFORMÁTICOS",
      "level": 3,
      "name": "TALLER DE MODALIDAD DE GRADUACIÓN",
      "code": "TMG-308"
    }
  ]
}
$catalog$::jsonb;
  career_name text;
  career_key text;
  career_id_found integer;
  subject_id_found integer;
  matches bigint;
  entry record;
BEGIN
  PERFORM pg_advisory_xact_lock(731202604);
  -- Serializa cambios del catálogo durante la carga.
  LOCK TABLE careers, subjects IN SHARE ROW EXCLUSIVE MODE;

  FOR career_name IN SELECT jsonb_array_elements_text(catalog->'careers') LOOP
    career_key := pg_temp.ibm_name_key(career_name);
    SELECT count(*), min(id) INTO matches, career_id_found
    FROM careers
    WHERE pg_temp.ibm_name_key(name) = career_key
       OR (career_key = 'COMERCIO INTERNACIONAL Y ADMINISTRACION ADUANERA'
           AND pg_temp.ibm_name_key(name) = 'COMERCIO INTERNACIONAL');
    IF matches > 1 THEN
      RAISE EXCEPTION 'Hay varias carreras equivalentes a %. Revisa el catálogo.', career_name;
    END IF;
    IF career_id_found IS NULL THEN
      INSERT INTO careers(name) VALUES (career_name) RETURNING id INTO career_id_found;
    ELSE
      UPDATE careers SET name = career_name WHERE id = career_id_found AND name <> career_name;
    END IF;

    FOR entry IN
      SELECT item->>'name' AS name, item->>'code' AS code,
             (item->>'level')::integer AS level,
             item->'previous_names' AS previous_names,
             row_number() OVER (PARTITION BY item->>'level' ORDER BY ord)::integer AS position
      FROM jsonb_array_elements(catalog->'subjects') WITH ORDINALITY AS source(item, ord)
      WHERE item->>'career' = career_name
      ORDER BY ord
    LOOP
      SELECT id INTO subject_id_found FROM subjects
      WHERE career_id = career_id_found AND level = entry.level AND upper(code) = entry.code;
      IF subject_id_found IS NULL THEN
        SELECT count(*), min(id) INTO matches, subject_id_found FROM subjects
        WHERE career_id = career_id_found AND level = entry.level AND code IS NULL
          AND (pg_temp.ibm_name_key(name) = pg_temp.ibm_name_key(entry.name)
               OR EXISTS (
                 SELECT 1 FROM jsonb_array_elements_text(entry.previous_names) AS old(name)
                 WHERE pg_temp.ibm_name_key(old.name) = pg_temp.ibm_name_key(subjects.name)
               ));
        IF matches > 1 THEN
          RAISE EXCEPTION 'Hay varias materias sin código que coinciden con %. Revisa el catálogo.', entry.name;
        END IF;
      END IF;

      IF subject_id_found IS NULL THEN
        INSERT INTO subjects(name, career_id, level, code, catalog_order)
        VALUES (entry.name, career_id_found, entry.level, entry.code, entry.position);
      ELSE
        UPDATE subjects SET name = entry.name, code = entry.code, catalog_order = entry.position
        WHERE id = subject_id_found
          AND (name, code, catalog_order) IS DISTINCT FROM (entry.name, entry.code, entry.position);
      END IF;
    END LOOP;
  END LOOP;

  RAISE NOTICE 'Catálogo de IBM cargado: 6 carreras y 141 materias oficiales.';
END;
$import$;

DROP FUNCTION pg_temp.ibm_name_key(text);
-- Retirar Diseño Gráfico cuando carece de vínculos académicos.
DELETE FROM subjects AS subject
USING careers AS career
WHERE subject.career_id = career.id
  AND upper(trim(career.name)) IN ('DISEÑO GRÁFICO', 'DISEÑO GRAFICO', 'DISENO GRAFICO')
  AND NOT EXISTS (SELECT 1 FROM offerings WHERE subject_id = subject.id)
  AND NOT EXISTS (SELECT 1 FROM academic_groups WHERE subject_id = subject.id)
  AND NOT EXISTS (SELECT 1 FROM subject_series WHERE subject_id = subject.id);

DELETE FROM careers AS career
WHERE upper(trim(career.name)) IN ('DISEÑO GRÁFICO', 'DISEÑO GRAFICO', 'DISENO GRAFICO')
  AND NOT EXISTS (SELECT 1 FROM subjects WHERE career_id = career.id)
  AND NOT EXISTS (SELECT 1 FROM students WHERE career_id = career.id)
  AND NOT EXISTS (SELECT 1 FROM study_plans WHERE career_id = career.id);
COMMIT;
