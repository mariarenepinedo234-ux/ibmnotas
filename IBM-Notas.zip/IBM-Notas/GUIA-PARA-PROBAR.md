# Ceicom con PostgreSQL · Instalación y pruebas

Esta versión usa **PostgreSQL 17** como base principal. Ya no crea ni utiliza SQLite al iniciar el servidor. Se conserva una herramienta para importar los archivos SQLite de la versión anterior.

## Opción recomendada: PostgreSQL con Docker Desktop

### 1. Requisitos

- Instala **Node.js 24 LTS** desde https://nodejs.org/.
- Instala **Docker Desktop** desde https://www.docker.com/products/docker-desktop/ y ábrelo. En Windows utiliza su motor Linux/WSL 2.
- Extrae el ZIP completo del repositorio. Abre una terminal dentro de la carpeta que contiene `package.json`.
- Comprueba `node --version` y `docker compose version`.

No necesitas MySQL, XAMPP ni instalar PostgreSQL por separado si utilizas Docker Desktop. La primera instalación requiere Internet para descargar paquetes e imagen.

### 2. Elige una base institucional o de demostración

**Para comenzar sin personas, materias ni notas ficticias:**

```sh
npm install
npm run configurar
docker compose up -d --wait db
npm run db:migrate
npm run crear-admin
npm run dev
```

`crear-admin` solicita usuario, nombre y contraseña en la terminal. La contraseña no se muestra y debe tener al menos 8 caracteres. El primer acceso exige cambiarla. Anota tus credenciales; no hay recuperación de contraseña desde la interfaz todavía.

**Para explorar con datos ficticios**, desde una carpeta y configuración nuevas:

```sh
npm install
npm run configurar -- --demo
docker compose up -d --wait db
npm run dev
```

Abre **http://localhost:3000**. Mantén la terminal del servidor abierta. Para detenerlo, pulsa **Ctrl+C**. Las próximas veces basta con `docker compose up -d --wait db` y `npm run dev`.

`configurar` genera una contraseña de PostgreSQL aleatoria en el archivo privado `.env`. Nunca sobrescribe un `.env` existente. Node y Docker Compose leen ese archivo. No lo publiques ni compartas. `SEED_DEMO=false` es el modo institucional; `true` permite la carga inicial de demostración en una base completamente vacía. Cambiarlo a false no borra datos que ya existan.

Si cambias `POSTGRES_PORT`, modifica también el puerto en `DATABASE_URL` y `TEST_DATABASE_URL`. La contraseña de un volumen PostgreSQL existente no cambia por editar `.env`: conserva juntos la configuración y el volumen, o cambia la contraseña mediante las herramientas de PostgreSQL.

### 3. Accesos solo de demostración

| Rol | Usuario | Contraseña inicial |
| --- | --- | --- |
| Administrador | `admin` | `Ceicom2026!` |
| Docente | `4567890` | `4567890` |
| Estudiante | `7000001` | `7000001` |

Estos accesos no se crean en modo institucional. La primera vez debes cambiar cada contraseña por una diferente de al menos 8 caracteres. Después usa la nueva; los botones de demostración completan únicamente la contraseña inicial.

El ejemplo tiene siete carreras, cuatro turnos, materias y módulos de 2026. Selecciona **Gestión 2026 → Módulo 4** para probar Programación I. El docente ve las materias por carrera y registra **Saber 40 + Hacer 40 + Ser 20**. Ejemplos: 20+30+10=60 (reprobado), 20+30+11=61 (aprobado), 40+40+20=100. Guarda todas las notas finales para descargar la planilla PDF o Excel. El estudiante `7000001` corresponde a Valentina Rojas.

Si el módulo ya venció, el administrador puede autorizar una reapertura desde Materias y asignaciones. El cierre restringe la edición, pero permite consultar y descargar planillas completas.

## Conservar los datos de la versión SQLite

**No borres `data/ceicom.sqlite` ni tu carpeta anterior.** Antes de actualizar, detén el sistema anterior y guarda una copia completa de su carpeta `data`, incluidos los archivos `-wal` y `-shm` si existen. Conserva los respaldos en una ubicación privada.

1. Extrae el proyecto nuevo en otra carpeta para conservar la versión anterior.
2. Ejecuta `npm install`, `npm run configurar`, `docker compose up -d --wait db` y `npm run db:migrate`.
3. No ejecutes `crear-admin` ni habilites demostración antes de importar: la base destino debe estar vacía.
4. Ejecuta, ajustando la ruta del archivo y usando comillas si contiene espacios:

```sh
npm run db:importar -- "C:/ruta/al/proyecto-anterior/data/ceicom.sqlite"
```

En macOS/Linux usa la ruta local correspondiente. También puedes copiar tu respaldo a `data/ceicom.sqlite` en el proyecto nuevo y ejecutar:

```sh
npm run db:importar -- ./data/ceicom.sqlite
npm run dev
```

La importación abre SQLite en modo de solo lectura y conserva identificadores, contraseñas ya cambiadas, expedientes, puntajes y actividad. Verifica cada valor importado y los conteos. Se ejecuta en una transacción: si hay un error, no se importa ninguna fila. Rechaza un destino con registros; no fusiona ni reemplaza bases existentes. Las sesiones antiguas no se importan: todos deben iniciar sesión de nuevo.

Las notas anteriores sin desglose conservan su total. Si un puntaje de la escala anterior supera Hacer 40 o Ser 20, se conserva y exige revisión antes de exportar una nueva planilla. Si el origen contiene fechas o relaciones inválidas, se informa el fallo y debe corregirse antes de repetir la importación.

Una base PostgreSQL ya usada, incluso si no tiene registros, conserva la posición de sus secuencias. La importación reajusta las secuencias para que los nuevos registros reciban identificadores disponibles.

## Opción alternativa: PostgreSQL instalado o alojado

Puedes usar un PostgreSQL 17 ya instalado, o un servicio administrado. Crea una base y un usuario propietario con contraseña propia. En `.env` configura:

```dotenv
DATABASE_URL=postgresql://USUARIO:CONTRASENA@SERVIDOR:5432/ceicom
SEED_DEMO=false
PORT=3000
COOKIE_SECURE=false
```

Codifica los caracteres especiales de usuario/contraseña como parte de una URL. Para un servidor remoto, utiliza el TLS y certificado que exija el proveedor; no desactives su verificación. `npm run configurar` es un ayudante para Docker local, no aprovisiona servidores remotos.

Ejecuta `npm install`, `npm run db:migrate`, `npm run crear-admin` y `npm run dev`. No necesitas los comandos Docker en esta opción. Para importar SQLite, sigue el procedimiento anterior antes de crear el administrador.

## Respaldos y recuperación

### Cargar carreras, materias y docentes desde el Excel institucional

Actualiza los archivos del proyecto conservando `.env`, SQLite y el volumen PostgreSQL. Ejecuta `npm install`, `npm run db:migrate` y `npm run dev`. Los botones Importar Excel ya no se muestran en Docentes ni en Materias y asignaciones. Para revisar el archivo desde la terminal ejecuta `npm run catalogo:importar -- "PLANILLA DE NOTAS 2026.xlsx"`; para guardarlo, repite el comando añadiendo `--aplicar`.

El catálogo de IBM incluye 163 materias por carrera y año. Para aplicar las materias corregidas sin importar el Excel desde el panel, ejecuta `npm run catalogo:actualizar` después de actualizar el proyecto. Usa **Editar** en el catálogo para corregir nombres, códigos o desactivar registros. Cambiar de carrera/año una materia que ya se dictó está restringido para conservar el historial.

Si importas el Excel completo por terminal, sus 23 docentes sin CI aparecerán en **Docentes → Docentes pendientes de CI**. Completa cada carnet con **Completar CI y habilitar** para crear su acceso. No se importan los estudiantes ni las notas de ejemplo de otras hojas.

Importante: descargar la nueva versión de GitHub no descarga la base ni los nombres de docentes. Debes importar tu Excel en tu instalación. El archivo original se conserva y no se publica en GitHub. El escudo institucional sí está incorporado al diseño de la aplicación y las planillas.

### Registrar grupos y completar datos pendientes

Antes de inscribir grupos, ejecuta `npm run db:migrate` y registra las personas con **Nuevo estudiante**. En **Estudiantes → Registrar grupo**, elige carrera y materia, ingreso, gestión cursada, año académico, turno, trimestre y docente. Marca a los estudiantes existentes que deseas incluir. Puedes buscar por nombre o CI y seleccionar todos los visibles. Repite para cada materia. Si el grupo ya existe, se agregan los marcados; para retirar inscritos usa **Editar inscritos**. Las fechas se corrigen desde **Gestiones y módulos → Editar trimestre**.

Los CI pueden quedar pendientes sin inventar números. Se registran materias e inscripciones, pero no se habilita el ingreso del estudiante. Usa **Completar datos** cuando tengas nombre y CI confirmados. Un docente del Excel que todavía no tenga CI puede figurar académicamente en sus materias; completa su CI desde su ficha para habilitar el acceso.

En la tabla **Grupos académicos**, el botón **Planilla** permite revisar cada lista y descargarla como borrador PDF/Excel. Se marca BORRADOR mientras falten notas; las filas vacías no son reprobados. Los documentos finales requieren todas las notas. Cargar grupos de un período ya terminado no abre el plazo del docente: administración registra las notas o autoriza una reapertura.

Las listas reales de este entorno no se publican en el ZIP de GitHub. En tu computadora debes registrar tus listas en el formulario o importar un archivo JSON privado según README.md. Conserva tus bases y archivos de respaldo.

### Respaldar o recuperar PostgreSQL

Desde el panel **Administración**, abre **Copias de seguridad** en el menú lateral y pulsa **Crear copia de seguridad**. Al finalizar, pulsa **Descargar**. El respaldo también queda en `backups/` en la carpeta del proyecto que ejecuta Node; si usas un servidor remoto, esa carpeta estará en el servidor. Cada archivo tiene un nombre distinto y puedes volver a descargarlo desde la lista.

Con PostgreSQL instalado en Windows, el sistema busca sus herramientas en `C:/Program Files/PostgreSQL/<versión>/bin`. Si indica que falta `pg_dump`, agrega a tu `.env` la ruta de la versión que tienes instalada, por ejemplo:

```dotenv
PG_BIN_DIR="C:/Program Files/PostgreSQL/17/bin"
```

Reinicia con `npm run dev`. No reemplaces las demás variables de tu `.env`. Las herramientas deben tener una versión compatible con tu servidor. El archivo descargado es un respaldo de PostgreSQL `.dump`, no un Excel.

Para aplicar esta actualización debes copiar también los archivos `server.js`, `db.js`, `backups.js`, las carpetas `scripts` y `public`; conserva `.env`, `backups` y tus archivos privados. No necesitas importar tablas ni modificar la base existente.

Con el PostgreSQL de Docker, para generar un respaldo privado:

```sh
npm run db:backup
```

O con nombre elegido:

```sh
npm run db:backup -- backups/ceicom-respaldo.dump
```

Se usa `pg_dump` en formato de respaldo PostgreSQL, con las tablas, índices, relaciones y migraciones del esquema `public`. El comando no sobrescribe un archivo existente. Conserva copias fuera de esa computadora, con acceso restringido: contienen datos personales y hashes de contraseñas.

Para restaurar, crea una **base vacía**, configura `DATABASE_URL` para apuntar a ella, detén el portal y ejecuta:

```sh
npm run db:restore -- backups/ceicom-respaldo.dump
```

El destino debe estar dentro del PostgreSQL de Docker configurado; una base diferente requiere crearla primero. La restauración se niega si hay tablas en el destino. Después ejecuta `npm run db:migrate` y `npm run dev`. No borra ni reemplaza automáticamente la base original.

Con un PostgreSQL externo o instalado, instala sus herramientas cliente `pg_dump`/`pg_restore` y usa `--native`:

```sh
npm run db:backup -- backups/ceicom-respaldo.dump --native
npm run db:restore -- backups/ceicom-respaldo.dump --native
```

Las herramientas deben estar en PATH o en la carpeta indicada mediante `PG_BIN_DIR`. El cliente PostgreSQL debe ser de una versión compatible con el servidor (17 en la instalación recomendada). Los respaldos son manuales por ahora: antes de producción programa su ejecución periódica y prueba la restauración en un destino separado.

## Pruebas y problemas frecuentes

Configura `TEST_DATABASE_URL` con una conexión **de desarrollo** cuyo usuario pueda crear esquemas y bases temporales. El archivo generado para Docker apunta al mismo servidor local y las pruebas crean y eliminan exclusivamente esquemas aleatorios `ceicom_test_*`; no usan las tablas de `public`. La prueba de restauración crea y elimina una base temporal `ceicom_restore_*` y usa las herramientas del compose de desarrollo. No apuntes las pruebas a producción.

```sh
npm test
```

Las pruebas ejecutan PostgreSQL real, no simulaciones. Verifican roles, notas, reportes, importación, administrador, migraciones y transacciones simultáneas.

- **Falta DATABASE_URL:** comprueba `.env`. Si venías de SQLite, el antiguo `DB_PATH` ya no configura la base; usa `DATABASE_URL`.
- **ECONNREFUSED / no conecta:** abre Docker Desktop, ejecuta `docker compose up -d --wait db` y revisa `docker compose ps`. Si usas PostgreSQL instalado, comprueba que el servicio esté iniciado.
- **Puerto 5432 ocupado:** elige otro `POSTGRES_PORT` en `.env` y actualiza las dos URL de conexión. Reinicia el servicio Docker sin eliminar el volumen.
- **PowerShell bloquea npm.ps1:** usa `npm.cmd install` y `npm.cmd run dev`, o abre CMD. No cambies las políticas de seguridad de Windows.
- **No encuentra package.json:** abre la terminal en la carpeta donde está ese archivo.
- **Puerto 3000 ocupado:** detén la otra instancia o cambia `PORT=3001` en `.env` y abre `http://localhost:3001`.
- **No hay usuarios ni materias:** es normal en modo institucional. Crea el administrador desde la terminal y registra los catálogos reales desde el panel. En demostración, elige Gestión 2026.
- **Contraseña incorrecta:** si ya la cambiaste, escribe la nueva. Los accesos iniciales no sustituyen contraseñas actualizadas.

Los datos están en el volumen persistente `ceicom_postgres`, no en SQLite. `docker compose stop db` conserva los datos; `docker compose down` también conserva el volumen. **No ejecutes `docker compose down -v`** si deseas conservar la base. No pierdas el `.env` que corresponde al volumen.

Esta es una base de desarrollo preparada para evolucionar hacia uso institucional. Antes de cargar expedientes reales: configurar alojamiento, HTTPS, usuarios PostgreSQL de privilegios mínimos, respaldos automáticos, recuperación de cuentas y revisión de privacidad. La instalación local de Docker usa un usuario propietario para facilitar migraciones; no es la política de permisos de producción.

## Subir y consultar planes de estudio

Actualiza el proyecto completo conservando tu `.env`, la carpeta `backups` y tus archivos privados. Detén el servidor con Ctrl + C y ejecuta desde la carpeta del proyecto:

```sh
npm install
npm run db:migrate
npm run dev
```

La nueva migración crea la tabla de planes y conserva tu información anterior. Al abrir el portal, presiona Ctrl + F5.

1. Ingresa como administrador y abre **Planes de estudio** en el menú.
2. Pulsa **Subir plan PDF**. Selecciona carrera y año académico (1º, 2º o 3º), indica el título y elige el PDF (máximo 20 MB).
3. Pulsa **Publicar plan**. Aparecerá dentro de su carrera y año.
4. Como docente, abre **Planes de estudio**. Puedes buscar por título, archivo o carrera y filtrar por carrera/año. **Ver PDF** abre otra pestaña; **Descargar** guarda el archivo en tu computadora.
5. Para actualizar un documento, el administrador puede pulsar **Eliminar**, confirmar y luego subir el PDF actualizado. El docente no tiene controles de carga o eliminación. Los estudiantes no acceden a este apartado.

Los PDF se guardan en PostgreSQL y se incluyen en las copias de seguridad de la base. Una restauración recupera tanto la información académica como los planes que existían al generar esa copia.

## Corregir estudiantes, listas y trimestres

Actualiza el proyecto completo conservando `.env`, `backups` y tus archivos privados. Con el servidor detenido ejecuta:

```sh
npm install
npm run db:migrate
npm run dev
```

La migración 005 conserva tus registros y permite usar la misma materia en distintos trimestres. Pulsa Ctrl + F5 al abrir el portal.

- **Inscribir un grupo:** Estudiantes → Registrar grupo. Elige carrera, año académico, materia, ingreso, gestión cursada, turno, trimestre y docente. Marca a las personas de la lista. Puedes buscar por nombre/CI y seleccionar todas las visibles. No se crean estudiantes desde aquí; usa Nuevo estudiante si falta alguno.
- **Agregar o retirar inscritos:** pulsa Editar inscritos en el grupo o en la materia. Marca para agregar y desmarca para retirar. Si retiras a alguien con notas o borradores, debes confirmar que se eliminarán también esos registros. Las notas restantes se conservan.
- **Corregir datos:** pulsa Editar o Completar datos en la fila del estudiante. Puedes corregir también el CI. Su historial conserva las inscripciones anteriores. Un CI corregido pasa a ser su usuario y conserva su contraseña.
- **Contraseña olvidada:** pulsa Restablecer clave, escribe y repite una contraseña temporal de mínimo 8 caracteres, distinta del CI, y comunícala al estudiante. Al ingresar deberá cambiarla. Las sesiones anteriores quedan cerradas.
- **Eliminar un registro erróneo:** pulsa Eliminar en la fila del estudiante, revisa identidad y cantidades y escribe ELIMINAR ESTUDIANTE. Se eliminarán sus inscripciones y notas de todas las gestiones. Los demás estudiantes no se eliminan.
- **Corregir un trimestre:** Gestiones y módulos → Editar trimestre. Modifica nombre o fechas; las fechas no pueden superponerse con otro período del mismo calendario. Si ya tiene asignaciones, conserva su gestión y calendario de ingreso.
- **Eliminar un trimestre:** pulsa Eliminar trimestre, revisa las cantidades y escribe ELIMINAR TRIMESTRE. Se eliminan ese período, sus asignaciones, grupos, inscripciones y notas. Las personas registradas, materias del catálogo y otros períodos se conservan.

Si el sistema indica que la información cambió durante una revisión, cierra el diálogo y vuelve a abrirlo para consultar la lista actual antes de confirmar. Puedes crear una copia desde Copias de seguridad para conservar un estado recuperable antes de una eliminación permanente.

## Aplicar las materias corregidas del Excel de noviembre

Detén el servidor con Ctrl + C y actualiza el proyecto completo, conservando `.env`, `backups` y tus archivos privados. Ejecuta desde la carpeta que contiene `package.json`:

```sh
npm install
npm run catalogo:actualizar
npm run dev
```

El comando usa los datos de materias incluidos en `catalogs/ceicom-2026.json`; no necesitas copiar el Excel a la carpeta del proyecto. Asegúrate de conservar también la carpeta `scripts` y el archivo `subject-catalog-update.js` de esta versión. Se aplican 163 materias oficiales; las complementarias existentes y sus notas permanecen. Las correcciones conservan los IDs de las materias, por lo que las asignaciones y planillas muestran los nombres corregidos. Una segunda ejecución no duplica registros.

Finalmente presiona Ctrl + F5. En **Materias y asignaciones** verás **Crear materia** y **Nueva asignación**, además del catálogo editable, sin el botón Importar Excel. Para comprobar las incorporaciones filtra el catálogo por Electrónica o Audiovisuales: cada carrera cuenta con 36 materias, 12 en cada año.

## Respetar el orden del Excel

La versión con la migración 006 guarda la posición de cada materia del Excel dentro de su carrera y año. Actualiza el proyecto completo conservando `.env`, `backups` y tus archivos privados, y ejecuta:

```sh
npm install
npm run catalogo:actualizar
npm run dev
```

Este comando aplica también las migraciones pendientes. El catálogo y los selectores mostrarán primero 1º año, luego 2º y 3º, siguiendo las filas del Excel y la secuencia de códigos correspondiente (101, 102, 103…). Electrónica mantiene la secuencia del archivo aunque varias materias tengan la misma numeración. Las complementarias como Power BI se conservan al final de su año. Los IDs y las notas permanecen iguales. Finalmente pulsa Ctrl + F5.

## Materias y asignaciones por docente

1. Entra como administrador a **Materias y asignaciones**: aparece una fila desplegable por docente con asignaciones en la gestión y módulo elegidos.
2. Pulsa un docente para ver sus materias, carreras, años, módulos, turnos y plazos. Puedes abrir varios a la vez y usar **Ver notas**, **Editar inscritos** y el candado de reapertura como antes.
3. Busca una materia, código, carrera, docente o turno: se abren las coincidencias. Borra la búsqueda para volver a los desplegables que habías abierto.
4. Cambia gestión o módulo y comprueba que cada docente muestra únicamente los grupos correspondientes. Una búsqueda sin resultados muestra un aviso.

Para esta actualización, reemplaza el proyecto conservando `.env`, `backups` y tus archivos privados, reinicia con `npm run dev` y pulsa Ctrl + F5. No requiere modificar la base de datos.

## Registrar ORATORIA en varias carreras a la vez

1. Abre **Materias y asignaciones → Crear materia** y escribe **ORATORIA**. Puedes dejar el código vacío.
2. Selecciona **3º año**, pulsa **Seleccionar todas** y desmarca **Diseño Gráfico**, **Electrónica** y **Diseño y Producción de Audiovisuales - Guionización**. Comprueba el contador de carreras seleccionadas.
3. Pulsa **Crear en carreras seleccionadas**. Revisa el catálogo: la materia aparece solo en las carreras elegidas y en 3º año. Guardar otra vez los mismos datos conserva las coincidencias sin duplicarlas. Si un nombre/código ya existe con otros datos, corrígelo desde Editar; el lote no se guarda parcialmente.
4. Para incorporar estudiantes de ingreso 2024, usa **Estudiantes → Registrar grupo**, elige carrera, 3º año, ingreso 2024, gestión cursada, trimestre, turno, docente y ORATORIA, y marca los estudiantes correspondientes. Crear la materia no los inscribe automáticamente.

Actualiza el proyecto conservando `.env`, `backups` y tus archivos privados; reinicia con `npm run dev` y pulsa Ctrl + F5. No requiere migraciones de PostgreSQL.

## Saludo completo y materias actuales del docente

1. Entra con cada uno de los tres perfiles y comprueba que el saludo incluya todo el nombre registrado. En móvil puede ocupar varias líneas.
2. Como docente, abre **Mi resumen** y **Mis materias y notas** con Todos los módulos. Las materias con grupos habilitados aparecen primero; dentro de cada estado, se muestran los módulos más recientes antes que los anteriores. Una misma materia conserva sus grupos por carrera y turno.
3. Filtra por módulo, carrera o búsqueda y comprueba que se ordenan las coincidencias. Un grupo de un trimestre anterior reabierto por administración también recibe prioridad mientras esté habilitado.

Actualiza el proyecto conservando `.env`, `backups` y tus archivos privados; reinicia con `npm run dev` y pulsa Ctrl + F5. No requiere migraciones de PostgreSQL ni cambiar los datos registrados.

## Alumno de 3º que debe una materia de 1º o 2º

1. Conserva al alumno en **3º año** y con su ingreso original, por ejemplo 2024. Conserva también la inscripción y la nota reprobada anterior.
2. Verifica que la materia pendiente tenga una asignación con docente, turno y trimestre de la gestión en que volverá a cursarla. Si falta, créala con **Nueva asignación**.
3. En **Materias y asignaciones**, abre el docente y pulsa **Editar inscritos** en esa asignación. Activa **Incluir estudiantes de años superiores con materias pendientes**, busca al alumno y marca su casilla. Los datos bajo su nombre muestran su año actual e ingreso.
4. Guarda. El alumno aparece en la lista del docente como materia pendiente; la nueva nota se registra allí. El expediente conserva ambos intentos, separados por trimestre/gestión.

También puedes usar **Inscribir estudiante** y marcar **Materia pendiente de un año anterior**. Se muestran las asignaciones compatibles de la misma carrera y turno. En **Registrar grupo**, elige el año de la materia (1º o 2º), el ingreso del alumno (2024), la gestión cursada y activa la opción de pendientes. Cambiar este filtro reinicia la selección. No se permite adelantar materias ni inscribir en otra carrera o turno con esta opción.

Para actualizar esta versión, conserva `.env`, `backups` y tus archivos privados, y ejecuta:

```sh
npm run db:migrate
npm run dev
```

La migración 007 añade una marca a las inscripciones; conserva las notas y los datos de los estudiantes. Después pulsa Ctrl + F5.

## Ver el año actual y el ingreso del alumno que recursa

Después de inscribirlo con la opción de materias pendientes, abre **Ver notas** y luego **Generar planilla de notas**. Bajo su nombre aparece, por ejemplo, **MATERIA PENDIENTE · 3º AÑO ACTUAL · INGRESO 2024**. La identificación se incluye también al descargar PDF o Excel y en su expediente. No tienes que escribirla manualmente.

El encabezado de la materia puede decir **CURSO: PRIMERO**, porque el alumno está recursando esa materia de 1º. La etiqueta bajo su nombre permite distinguirlo de los alumnos regulares. **INGRESO 2024** es su gestión de ingreso; la gestión de la planilla corresponde al período en que está cursando la materia.

Actualiza el proyecto completo conservando `.env`, `backups` y archivos privados, reinicia con `npm run dev` y pulsa Ctrl + F5. Esta identificación usa la migración 007 de la versión anterior; si aún no la aplicaste, ejecuta `npm run db:migrate` antes de iniciar.

## Consultar materias cursadas y por aprobar como estudiante

1. Entra como estudiante y pulsa **Mi historial académico** en el menú, o **Ver mi historial y las materias por aprobar** desde el resumen.
2. Revisa las tarjetas: materias del plan, aprobadas, por aprobar y sin inscripción. El avance incluye todo el historial, aunque el resumen estuviera filtrado por una gestión anterior.
3. Filtra por 1º/2º/3º año, por estado o busca una materia/código. **Por aprobar** reúne reprobadas, inscritas, notas pendientes y materias sin inscripción.
4. Abre **Ver registros** en una materia para consultar sus distintos intentos. Una reprobación seguida de una aprobación cuenta como una sola materia aprobada; la nota anterior se conserva.
5. Revisa la sección de complementarias y planes anteriores. Sus notas se conservan, pero se muestran aparte del avance del plan vigente. Si una materia ya cursada aparece Sin inscripción, solicita a secretaría completar sus registros anteriores al uso del portal.

Actualiza el proyecto completo conservando `.env`, `backups` y tus archivos privados; reinicia con `npm run dev` y pulsa Ctrl + F5. No requiere nuevas migraciones respecto de la versión 007. Para que el plan refleje el Excel revisado, administración debe haber aplicado el catálogo mediante `npm run catalogo:actualizar`.


## Cuarto trimestre con fechas diferentes para ingreso 2026

1. Actualiza el proyecto completo conservando `.env`, `backups` y archivos privados. Ejecuta `npm run db:migrate`, inicia con `npm run dev` y pulsa Ctrl + F5.
2. En **Gestiones y módulos → Nuevo módulo**, escribe **CUARTO TRIMESTRE PRIMER AÑO 2026**.
3. Elige **Gestión cursada: 2026** y **Calendario para ingreso: Ingreso 2026**. Indica **inicio 07/09/2026** y **fin 30/11/2026**.
4. Guarda. Puede coincidir con el cuarto trimestre compartido del 05/10/2026 al 18/12/2026, que conserva sus fechas para ingresos 2024 y 2025.
5. Al usar **Nueva asignación** o **Registrar grupo**, selecciona el nuevo módulo para los alumnos de ingreso 2026. En Registrar grupo, sin la excepción de pendientes, la lista mostrará el calendario correspondiente al ingreso elegido.
6. Usa **Calendario por ingreso** para revisar las fechas de cada ingreso. Si otros trimestres de ingreso 2026 también tienen fechas diferentes, créalos en su propio calendario. Los períodos compartidos que coincidan con uno propio dejan de ofrecerse para nuevas inscripciones regulares de ese ingreso.

La migración conserva las asignaciones y notas previas. Crear un módulo nuevo no mueve estudiantes ni cambia las notas de asignaciones anteriores. Los módulos se identifican por su calendario, aunque tengan nombres parecidos. Los plazos de notas de cada docente se calculan según la fecha final del módulo asignado.


## Inscribir alumnos desde un módulo

1. Entra como administrador a **Gestiones y módulos** y pulsa **Ver materias y grupos** en la tarjeta del trimestre deseado.
2. Localiza la materia y carrera en la lista por docente. Usa **Inscribir / editar estudiantes** para marcar varios alumnos o **Inscribir uno** para una inscripción individual. Revisa el turno y el calendario de ingreso.
3. Guarda y comprueba que aumente el contador. Las notas de los alumnos que permanecen inscritos se conservan.
4. Para una asignación nueva, usa **Asignar materia**; para registrar el grupo y sus alumnos juntos, usa **Registrar grupo**. Ambos formularios mantienen seleccionado el módulo de origen. Si todavía no hay asignaciones, estos botones permiten comenzar.
5. Desde cada fila también puedes abrir **Ver notas** o **Planilla**. La búsqueda permite encontrar materia, código, carrera, docente o turno dentro de ese módulo.

En **Docentes** se muestra Nuevo docente y se conservan los pendientes de CI; se retiró Importar Excel. Actualiza el proyecto completo conservando `.env`, `backups` y archivos privados, reinicia con `npm run dev` y pulsa Ctrl + F5. No requiere nuevas migraciones si ya aplicaste la versión 008.

## Buscar rápidamente un alumno por gestión

En **Estudiantes**, selecciona **Gestión de ingreso → Ingreso 2024**, por ejemplo. Puedes combinarlo con carrera, turno y nombre o carnet para localizar al alumno. Desde su fila usa **Restablecer clave** o el botón de expediente. La gestión elegida permanece al cerrar esos formularios.

Se filtra por el año en que ingresó, no por la gestión actual de cursada. Para volver a todos, selecciona **Todas las gestiones** y limpia los demás filtros si corresponde. Actualiza el proyecto conservando `.env`, `backups` y archivos privados, reinicia con `npm run dev` y pulsa Ctrl + F5. Esta mejora no añade migraciones de PostgreSQL.

## Recuperar el acceso de un docente

1. Como administrador, abre **Docentes** y busca al docente por nombre o CI.
2. Pulsa **Restablecer contraseña** en su tarjeta y verifica el nombre y CI del formulario.
3. Escribe y repite una contraseña temporal de entre 8 y 160 caracteres, distinta del CI. Guarda y comunícala al docente.
4. El docente ingresará con su mismo CI y esa contraseña temporal. Antes de ver el panel deberá cambiarla por una contraseña personal. Sus sesiones anteriores se cierran y sus materias y notas se conservan.

Si todavía tiene CI pendiente, primero usa **Completar CI y habilitar**. Actualiza conservando `.env`, `backups` y archivos privados, reinicia con `npm run dev` y pulsa Ctrl + F5. No requiere nuevas migraciones.

## Continuar una materia por partes y calcular el promedio final

1. Actualiza el proyecto conservando `.env`, `backups` y archivos privados. Reinicia con `npm run dev`: se aplicará la migración **009_subject_parts.sql**. Pulsa Ctrl + F5.
2. Como administrador, entra a **Materias y asignaciones**, abre al docente y localiza la materia y carrera. Pulsa **Continuar materia**. La misma opción está en la lista de materias y grupos de cada módulo.
3. Elige un trimestre que empiece después de finalizar el anterior y un docente. Marca los estudiantes que continuarán. El calendario debe corresponder a su ingreso; los alumnos de años superiores conservan la excepción de materias pendientes. La asignación anterior pasa a ser PARTE I sin perder sus notas; la nueva PARTE II empieza sin notas.
4. Para una PARTE III o IV, vuelve a usar **Continuar materia** desde la última parte original. Las materias que no necesiten continuación se dejan como están.
5. Cada docente registra sus notas y genera las planillas de su parte. El nombre identifica PARTE I, II, III, etc.; la columna corresponde a la nota de esa parte.
6. Cuando ya no habrá más partes, pulsa **Concluir materia** en la última parte original. El promedio usa todas las partes con el mismo peso y dos decimales; cada parte debe aprobarse con al menos 61. Si falta una nota o inscripción, el promedio final queda pendiente.
7. Si un alumno reprueba una parte, pulsa **Recuperar parte** en esa asignación y elige el trimestre y los estudiantes que recuperarán. Se guarda un nuevo intento de esa misma parte y se conservan los anteriores. No crea una PARTE adicional ni repite las partes aprobadas.
8. En **Mi historial académico**, el estudiante abre los registros de la materia para ver las partes y sus intentos. El administrador también consulta el resumen desde el expediente del alumno. Ejemplo: 65, 50 y 85 requieren recuperar la segunda parte; si después obtiene 80 en esa recuperación, la materia queda aprobada con 76,67.

**Reabrir materia** devuelve una materia concluida al estado en curso para agregar otra parte, conservando las notas. Después hay que concluirla nuevamente. Los módulos con partes vinculadas no se pueden eliminar, para conservar la secuencia y el historial. No es necesario volver a importar las materias ni registrar otra vez a los estudiantes.

## Ya asigné la misma materia al tercer y cuarto trimestre

Crear las dos asignaciones con **Nueva asignación** las registra como independientes. Para relacionarlas como partes:

1. En **Materias y asignaciones**, abre al docente y ubica el grupo del **tercer trimestre**.
2. Pulsa **Continuar materia**. En Trimestre de destino, elige la opción **VINCULAR EXISTENTE** que corresponde al cuarto trimestre.
3. Revisa el docente, la cantidad de estudiantes y las notas guardadas que informa la pantalla. Pulsa **Vincular como PARTE II**.
4. Comprueba que el tercero aparezca como **PARTE I** y el cuarto como **PARTE II**. Se conservan ambas listas, sus docentes y las notas anteriores; esta operación no incorpora estudiantes nuevos. Puedes usar Editar inscritos después si necesitas ajustar una lista.
5. Al terminar todas las partes, usa **Concluir materia** en la última parte original para habilitar el promedio final de cada alumno con todas sus partes aprobadas.

El formulario **Nueva asignación** ahora avisa cuando la materia ya tiene asignaciones y ofrece Continuar materia desde allí, con módulo y docente de destino precargados. Un trimestre vencido no convierte automáticamente la materia en PARTE I: las partes se establecen mediante la continuación explícita. El sistema comprueba misma materia, turno, orden de fechas y grupos compatibles; únicamente administración puede vincularlos.

Actualiza el proyecto conservando `.env`, `backups` y archivos privados. Ejecuta `npm install`, reinicia con `npm run dev` y pulsa Ctrl + F5. Si ya tienes aplicada la migración 009, esta mejora no necesita migraciones adicionales.

## Inscribir toda la lista de una materia y eliminar una asignación equivocada

1. Como administrador, abre **Gestiones y módulos → Ver materias y grupos** o la lista por docente en **Materias y asignaciones**.
2. En la fila de la materia, pulsa **Registrar grupo**. Por ejemplo, PROGRAMACIÓN I, SISTEMAS INFORMÁTICOS, 1º año, MAÑANA. El contexto de esa asignación queda fijado; no tienes que seleccionarlo nuevamente.
3. Revisa **Gestión de ingreso** y los conteos de estudiantes por año. La lista muestra únicamente estudiantes registrados compatibles con la carrera, año, turno, ingreso y calendario de esa materia. Usa **Seleccionar visibles** para marcarla completa o marca solo algunas casillas. Guarda con **Registrar grupo e inscripciones**.
4. Para ajustar una lista existente, usa **Inscribir / editar estudiantes**. Su filtro de ingreso conserva a los seleccionados de otras gestiones: cambiar el filtro no los retira. Desmarcar estudiantes con notas requiere confirmar expresamente la retirada de esas notas.
5. Si aparecen 0 alumnos de 1º y hay alumnos de 3º, revisa su año actual en Estudiantes. Para quienes realmente deban la materia de 1º, activa **Incluir estudiantes de años superiores con materias pendientes**. Sus perfiles y notas anteriores se conservan. Un ingreso con otro calendario debe utilizar su módulo correspondiente.
6. Si creaste una asignación equivocada, pulsa **Eliminar materia** en esa fila. Revisa el módulo, carrera, turno, docente y las cantidades de inscripciones y notas. Para eliminar, escribe **ELIMINAR ASIGNACION**. Se retira esa asignación junto con su lista y notas; los estudiantes, docentes, catálogo y otras asignaciones se conservan. Si cambió la lista desde la revisión, vuelve a abrirla antes de confirmar.

Las asignaciones vinculadas a partes I, II, III, etc. se conservan para proteger el historial y los promedios; la pantalla explica esa protección. El botón elimina una asignación de un módulo, no el registro de la materia del catálogo. Para corregir solamente su nombre, usa la edición del catálogo.

Actualiza conservando `.env`, `backups` y archivos privados, ejecuta `npm install`, reinicia con `npm run dev` y pulsa Ctrl + F5. No requiere nuevas migraciones si ya aplicaste la 009.
